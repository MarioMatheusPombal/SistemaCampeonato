package SistemaCampeonato;

public class Endereco {
	private String logradouro;
	private int num,cep;
                  private static int cont=0;
                  private int id;
	public Endereco(String logradouro, int num, int cep) {
		super();
		this.logradouro = logradouro;
		this.num = num;
		this.cep = cep;
                                    cont+=1;
                                    this.id = cont;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getCep() {
		return cep;
	}
	public void setCep(int cep) {
		this.cep = cep;
	}
	@Override
	public String toString() {
		return "Endereco [Id= "+id+" logradouro= " + logradouro + ", num= " + num + ", cep= " + cep + "]\n";
	}

    public int getId() {
        return id;
    }
                  
	
}
