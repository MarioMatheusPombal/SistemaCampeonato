package SistemaCampeonato;


public class Jogador {
	private String nome,genero,altura,tipoJgd;
	private String datant;
                  private static int cont=0;
                  private int id;
	public Jogador(String nome, String genero, String altura, String tipojgd, String datant) {
		this.nome = nome;
		this.genero = genero;
		this.altura = altura;
		this.tipoJgd = tipojgd;
		this.datant = datant;
                                    cont+=1;
                                    this.id = cont;
	}
                 public int getId() {
                                    return id;
                 }
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getAltura() {
		return altura;
	}
	public void setAltura(String altura) {
		this.altura = altura;
	}
	public String getTipojgd() {
		return tipoJgd;
	}
	public void setTipojgd(String tipojgd) {
		this.tipoJgd = tipojgd;
	}
	public String getDatant() {
		return datant;
	}
	public void setDatant(String datant) {
		this.datant = datant;
	}
	@Override
	public String toString() {
		return "Jogador [id= "+id+" nome= " + nome + ", genero= " + genero + ", altura= " + altura + ", tipoJgd= "  + tipoJgd
				+ ", datant= "  + datant + "]\n";
	}
	
	
}
