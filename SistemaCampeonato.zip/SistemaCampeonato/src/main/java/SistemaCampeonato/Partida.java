package SistemaCampeonato;

import java.text.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class Partida {

	private String status;
	//private Date data = new Date();
                  private String data;
	private Estadio estadio;
	private String nometimes;
	ArrayList<Time> times = new ArrayList();
                  private static int cont=0;
                  private int id;
	
	
	public Partida(String nomeTimes, Estadio estadio,String data) {
		super();
		this.estadio = estadio;
		this.nometimes = nomeTimes;
		cont+=1;
                                    this.id = cont;
	}
	public String getNometimes() {
		return nometimes;
	}

	public void setNometimes(String nometimes) {
		this.nometimes = nometimes;
	}

	public Time getTime(int pos) {
		return times.get(pos);
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getData() {
		return data;
	}
	/*public void setData(String data) throws ParseException {
		Date hoje = new Date();
		
		
		Locale.setDefault(new Locale("pt", "Brazil"));
		String hojeFormatado = DateFormat.getInstance().format(hoje);
		SimpleDateFormat sdformat = new SimpleDateFormat("dd/MM/yyyy");
		hoje = sdformat.parse(hojeFormatado);
		this.data = sdformat.parse(data);
		if(hoje.compareTo(this.data)>0) {
			setStatus("Finalizado");
		}
		if(hoje.compareTo(this.data)<0) {
			setStatus("Aguardando");
		}
		if(hoje.compareTo(this.data)==0) {
			setStatus("Aguardando");
		}
	}*/
	public Estadio getEstadio() {
		return estadio;
	}
	public void setEstadio(Estadio estadio) {
		this.estadio = estadio;
	}

                    public int getId() {
                        return id;
                    }
                  
	@Override
	public String toString() {
		
		String auxiliar = "";
		for(Time t: times) {
			auxiliar+=" "+t.getNome();
		}
		return "Partida [Id: "+id+" Os times que jogaram nesta partida : "+auxiliar + ", status= " + status + ", data= " + data + ", estadio= "
					+ estadio + "\n";

		}
	

	//-------------------------------------
	//Adicionar e Remover Time
	//-------------------------------------
	public void insereTime(Time time) {
		times.add(time);
	}
	public void removeTime(Time time) {
		times.remove(time);
	}
	//-------------------------------------
	//Buscar Time
	//-------------------------------------
	public String buscaTime(String nome) {
		for (Time time : times) {
			if(nome.equalsIgnoreCase(time.getNome())) {
				return "\n"+time.infoTime();
			}
		}
		return null;
	}
		
	//-------------------------------------
	//Ordenar e Listar todos Times
	//-------------------------------------
	public String getTimes() {
		OrdenaTime comparador = new OrdenaTime();
		String nomesTimes = "";
		times.sort(comparador);
		for(Time t: times) {
			nomesTimes+=" "+t.getNome();
		}
		return "Os times dessa partida são:"+nomesTimes;
	}
		
	class OrdenaTime implements Comparator<Time>{

		@Override
		public int compare(Time t1, Time t2) {
			if(t1.getPontos() < t2.getPontos()) {
				return 1;
			}
			if(t1.getPontos() > t2.getPontos()) {
				return -1;
			}
			return 0;
		}
		
	}
	
}
