package SistemaCampeonato;

public class Estadio {
	private String nome;
	private Endereco endereco;
                  private static int cont=0;
                  private int id;
	public Estadio(String nome, Endereco endereco) {
		super();
		this.nome = nome;
		this.endereco = endereco;
                                    cont+=1;
                                    this.id = cont;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	@Override
	public String toString() {
		return "Estadio [[Id= "+id+" nome= " + nome + ", endereco= " + endereco + "]\n";
	}

    public int getId() {
        return id;
    }
        
	
}
