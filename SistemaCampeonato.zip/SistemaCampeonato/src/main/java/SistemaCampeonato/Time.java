package SistemaCampeonato;

import java.util.ArrayList;
import java.util.Comparator;

public class Time {
	private String nome;
	private Estadio estadio;
	ArrayList<Jogador> jgds = new ArrayList();
	private int vtr,goal,pontos;
	private static int cont=0;
                  private int id;
	
	public Time(String nome,Estadio estadio) {
		super();
		this.nome = nome;
		this.estadio = estadio;
                                    cont+=1;
                                    this.id = cont;
	}
	public Estadio getEstadio() {
		return estadio;
	}
	public void setEstadio(Estadio estadio) {
		this.estadio = estadio;
	}
	public int getVtr() {
		return vtr;
	}
	public void setVtr(int vtr) {
		this.vtr = vtr;
	}
	public int getGoal() {
		return goal;
	}
	public void setGoal(int goal) {
		this.goal = goal;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getPontos() {
		pontos = getVtr()+getGoal();
		return pontos;
	}

                public int getId() {
                    return id;
                }
                public void addVtr(int vtr){
                    this.vtr +=vtr;
                }
                public void addGoal(int goal){
                    this.goal+=goal;
                }
                  
	@Override
	public String toString() {
		String aux = "";
		for (Jogador jogador : jgds) {
			aux+=jogador.getNome();
		}
		return "Time [nome=" + nome + ", estadio=" + estadio + ", jogadores=" + aux + ", vtr=" + vtr + ", goal="
				+ goal + "]";
	}
	public String infoTime() {
                                    String aux = "";
		for (Jogador jogador : jgds) {
			aux+=" "+jogador.getNome();
		}
		return "[Id= "+id+" Nome do time: "+getNome()+" Quantidade de vitórias: " + getVtr()+" Quantidade de Gols: "+getGoal() +" Total de pontos: " + getPontos()+" Jogadores: "+aux+"\n-------------------\n";
		}
	//-------------------------------------
	//Adicionar e remover Jogadores
	//-------------------------------------
	public void insereJgd(Jogador jgd) {
		jgds.add(jgd);
	}
	public void removeJgd(Jogador jgd) {
		jgds.remove(jgd);
	}
	
	//-------------------------------------
	//Buscar Jogadores
	//-------------------------------------
	public String buscaJGD(String nome) {
		for (Jogador jogador : jgds) {
			if(jogador.getNome().equalsIgnoreCase(nome)) {
				return jogador.getNome();
			}
		}
		return null;
	}
	
	//-------------------------------------
	//Ordenar e Listar todos Jogadores
	//-------------------------------------
	
	public String listaJGD() {
		Comparador comp = new Comparador();
		String aux = "";
		jgds.sort(comp);
		for (Jogador jogador : jgds) {
			aux += "\n"+jogador.getNome();
		}
		return aux;
	}
	
	class Comparador implements Comparator<Jogador>{

		@Override
		public int compare(Jogador j1, Jogador j2) {
			return j1.getNome().compareTo(j2.getNome());
		}
		
	}
	
	
}
