package SistemaCampeonato;
import java.util.ArrayList;
import java.util.Comparator;

public class Campeonato {
	private String nome;
	ArrayList<Partida> ptds = new ArrayList();
	ArrayList<Time> times = new ArrayList();
	private String classificacao = "";
	private static int cont=0;
                  private int id;
                  
	public Campeonato(String nome) {
		this.nome = nome;
                                    cont+=1;
                                    this.id = cont;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

                    public int getId() {
                        return id;
                    }
	
	@Override
	public String toString() {
                                    String auxiliar = "";
		for(Partida p: ptds) {
			auxiliar+=" "+p.getNometimes();
		}
		return "Id= "+id+"Campeonato [partidas=" + auxiliar + ", classificacao=" + classificacao + "]";
	}
	//-------------------------------------
	//Adicionar e Remover Partida e Time
	//-------------------------------------
	public void adicionaPtd(Partida ptd) {
		ptds.add(ptd);
	}
	
	public void removePtd(Partida ptd) {
		ptds.remove(ptd);
	}
	
	public void insereTime(Time time) {
		times.add(time);
	}
	
	public void removeTime(Time time) {
		times.remove(time);
	}
	
	//-------------------------------------
	//Buscar Partida
	//-------------------------------------
		public String filtraPtd(String stts) {
			String aux = "";
			for (Partida partida : ptds) {
				if(partida.getStatus().equalsIgnoreCase(stts)) {
					aux+=partida.getNometimes()+"  "+partida.getStatus()+"  "+partida.getData();
				}
			}
			return aux;
	}
	//-------------------------------------
	//Classificacao dos times e Comparador
	//-------------------------------------
	
		public String getClassificacao() {
			Classificacao comparador = new Classificacao();
			times.sort(comparador);
			for (Time t : times) {
				classificacao += t.infoTime();
			}
			return classificacao;
		}
	
		
	class Classificacao implements Comparator<Time>{
		@Override
		public int compare(Time t1, Time t2) {
			if(t1.getPontos() < t2.getPontos()) {
				return 1;
			}
			if(t1.getPontos() > t2.getPontos()) {
				return -1;
			}
			return 0;
		}
	}
	
}
